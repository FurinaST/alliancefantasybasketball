<style>
    .main {
        position: relative;
        z-index: 1;
    }

    h4, h5 {
        text-align: center;
    }

    .footballHolder {
        text-align: center;
        padding: 2em 0;
    }

    h4 {
        color: var(--blueOne);
        font-weight: 700;
        margin: 3em 0 1em;
    }

    .football {
        width: 80%;
        max-width: 300px;
        height: auto;
    }
</style>

<div class="main">
    <h4>
        Hut, Hut, Blue 404!
    </h4>
    <div class='footballHolder'>
        <img class='football' src='/deflated-football.png' alt='deflated football' />
    </div>
    <h5>
        Nothing Here... Try Another Page!
    </h5>
</div>